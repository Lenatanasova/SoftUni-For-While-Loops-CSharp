﻿//Write a program to apply a 20% bonus for certain number: 
//•	Reads an integer number from the console: the "stop number"
//•	Keep reading integers until it finds the stop number
//•	When the stop number is found, increase the value of the previous number before it with 20% and print it

int stopNum = int.Parse(Console.ReadLine());

int lastNum = 0;

while (true)
{
    int currentNum = int.Parse(Console.ReadLine());

    if (currentNum == stopNum)
    {
        double exit = lastNum * 1.2; //adding 20%
        Console.WriteLine(exit);
        break;
    }

    lastNum = currentNum;

}