﻿//Write a program to check if given number is special: 
//•	Special numbers are divisible by all of their digits without remainder
//•	Reads an integer number and check whether it is a special number
//•	If the number IS special print: "{num} is special"
//•	If the number is NOT special print: "{num} is not special"

using System.Diagnostics;

int n = int.Parse(Console.ReadLine());

int nCopy = n;

bool isSpecial = false;

while (nCopy > 0)
{
    int lastDigit = nCopy % 10;
    if (n % lastDigit == 0)
    {
        isSpecial = true;
    }
    else
    {
        isSpecial = false;
        break;
    }

    nCopy /= 10; //nCopy = nCopy/10
}

if (isSpecial)
{
    Console.WriteLine($"{n} is special");
}
else
{
    Console.WriteLine($"{n} is not special");
}
