﻿int d = int.Parse(Console.ReadLine());

for (int i = d; i>= 1; i--)
{
    Console.WriteLine($"{i} days before the exam");
}
Console.WriteLine("The exam has come");