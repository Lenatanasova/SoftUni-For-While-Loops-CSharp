﻿char start = char.Parse(Console.ReadLine());
char end = char.Parse(Console.ReadLine());

for (char c = start; c <= end; c++)
{
    Console.Write(c + " ");
}
