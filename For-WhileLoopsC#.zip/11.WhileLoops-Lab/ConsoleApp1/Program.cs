﻿int a = 1;

while(a<=100)
{
    Console.WriteLine(a);
    a++;
}